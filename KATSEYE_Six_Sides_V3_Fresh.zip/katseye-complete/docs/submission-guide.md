# Submission Guide

Assignment 2 asks for: pre-proposal; finished artifact; original inputs/prompts; two intermediate versions; AI strengths/weaknesses; material human decisions; provenance.

- Pre-proposal: `docs/pre-proposal.md`
- Finished artifact: `index.html` (open in Safari/Chrome; interactive and mobile responsive)
- Original inputs and prompts: `docs/ai-process.md` plus research URLs in `docs/research.md`
- Intermediate version 1: `versions/v0-original.html` (earlier generic functioning prototype)
- Intermediate version 2: `versions/v1-strategy.md` (source-informed revised concept)
- Final functional iteration: `index.html`
- AI strengths/weaknesses and human decisions: `docs/ai-process.md`
- Provenance: `docs/research.md` and `docs/ai-process.md`

## Quick functional test
1. Open index.html. Click Fan experience, edit city/message/color/language and download a PNG.
2. Click Business model; change orders, pricing and costs; verify contribution and break-even update.
3. Click Brand pitch and print/save as PDF if needed.
4. Open Research and AI process for transparency.

## Before final submission
- Personally inspect the brand concept and add an authentic student reflection.
- Make any changes you actually believe improve the strategy and preserve them.
- Check professor's exact required file formats and Canvas deadline.
- Do not present the concept as an approved KATSEYE or instax collaboration.
