# SIX SIDES / ONE WORLD — Commercial strategy & partner handoff
**As of November 1, 2026 · Academic speculative proposal · No authorization or commercial discussions**

## Executive recommendation
**Conditional recommendation: pilot, not full global launch.** KATSEYE × FUJIFILM instax is a credible *hypothesis* for moving from high-reach artist endorsements into fan-created, optional physical products. It is not proven that fans want this offer or that a license can be secured. A low-commitment market pilot is more defensible than a global rollout.

## What the partner would actually buy
- **Brand-side buyer:** global brand partnerships / regional marketing leads at Fujifilm instax, subject to distributor and licensing approval. Their business case is product trial, brand preference, and incremental print/film use, not merely campaign views.
- **Artist-side buyer/user:** KATSEYE management / commercial partnerships team, already sophisticated and represented. This project **augments** their research-to-pitch workflow; it does not claim to find them their first sponsor.
- **Service proposition under study:** AI-assisted synthesis of artist, category and territory evidence; concept and activation generation; rights-aware deal architecture; localization; exportable decision briefs. An experienced human still owns relationship, approvals, brand fit and economics.

## Artist intelligence (public, dated)
- Official artist biography: six members with distinct backgrounds; HYBE × Geffen global pop project. https://www.katseye.world/story-of-katseye/
- Chartmetric Oct 31 2026 snapshot: Spotify ~34.3m monthly listeners, Instagram ~9.8m followers, TikTok ~22.2m followers. https://app.chartmetric.com/artist/12149515/audience
- StreamClout Oct 30 2026: ~438k São Paulo monthly listeners (third-party city estimate). https://streamclout.io/artist/katseye/3c0gDdb9lhnHGFtP4prQpn
- Spotify monthly listeners are not paying fans, unique cross-platform people, or conversion rates. No demographic purchase profile was available; do not invent one.
- Gap official Aug 19 2025 release: *Better in Denim*, dance-led global campaign and $70 limited-edition KATSEYE hoodie. This proves **precedent for a physical merchandise extension**; it does not validate instax economics. https://www.gapinc.com/es-us/articles/2025/08/gap-unveils-fall-denim-campaign-starring-global-gi
- LANEIGE Jan 26 2026 partnership: sound-to-color lip tint campaign; demonstrates beauty category saturation/conflict diligence. https://www.prnewswire.com/news-releases/laneige-unveils-katseye-as-global-partner-and-faces-of-new-juicepop-box-lip-tint-campaign-302670191.html
- Official instax mini Link 3: smartphone photo printer with app, collage and AR features. **Do not claim direct website-to-printer integration**. https://www.instax.com/mini_link_3/en/

## Why instant photography?
**Artist fit:** KATSEYE's official narrative is multinational individuality within a group. **Brand fit:** instax makes phone-originated creative moments physical; the mini Link category has a direct product trial story. **Business bridge:** free digital engagement → optional authorized print experience → possible printer/film sales or paid partner activation. This is an *incremental activation hypothesis*, not a discovered unserved market.

### Alternatives not selected
1. **Beauty product:** substantial overlap with known LANEIGE and Matrix activity; category exclusivity must be checked. Generic cosmetic endorsement adds little new insight.
2. **Fashion merch:** proven Gap precedent, but repeating a hoodie campaign would be less distinct.
3. **Gaming virtual goods:** interesting IP monetization but rights, platform integrations, game development and virtual-item policy increase prototype complexity.
4. **Instant photo memories:** an independently demoable fan activity and an identifiable brand product; still carries potential category/territory conflict and low monetization certainty.

## Activation design
**Campaign:** SIX SIDES / ONE WORLD — 'Keep a moment from your city'. Fans generate a personalized city memory card on their own device, choose language and colors, save a PNG without creating an account, and optionally use an instax-compatible workflow *if validated* to print it. No KATSEYE likeness/music/trademarks are embedded in the generated card. An official launch would require all necessary rights and branded artwork approvals.

**Brand touchpoints:** a mobile creation page; optional retailer photo station; staff demonstration of approved hardware; localized social instructions; transparent product offers. Do not promise artist messages, signed collectibles or guaranteed personal interaction. Avoid manipulative rarity/random reward mechanics.

**Business model options (mutually negotiable, not additive promises):**
- Brand pays a fixed creative/campaign sponsorship fee for rights, talent participation and activation, subject to contract.
- Partner may capture incremental hardware and consumables revenue, *not* counted as project revenue unless attributable and supported by sales records.
- Optional artist licensing royalty on authorized physical merchandise; percentages in the calculator are illustrative only.
- Pilot service provider could charge a scoped research/prototype/activation fee. Never assume a transaction commission without agency and legal review.

## Territory sequencing
| Territory | Why consider it | Localization | Distribution assumption | Specific stop/go question |
|---|---|---|---|---|
| US / LA or NYC | KATSEYE based in LA; accessible US instax product pages | English | Verify actual retail stores, inventory and permission | Does print trial improve product consideration over a non-artist comparison? |
| Philippines / Manila | Sophia's documented Manila origin gives cultural relevance | English/Filipino, native reviewed | Distributor and price to be confirmed | Is the experience accessible, affordable and understood? |
| Brazil / São Paulo | Third-party Spotify city listening signal | Brazilian Portuguese, native reviewed | Distributor, import, tax, logistics to be confirmed | Does observed engagement translate into qualified trial without inflated CAC? |

**No claim** that these are the largest or highest-spending fan markets. A city-listening signal cannot be extrapolated to sales. Other possible markets: Korea, Malaysia, Mexico, UK; further investigation required.

## Rights, execution and ethics
1. HYBE/Geffen/KATSEYE talent/name/image/music approval and master/publishing rights if songs are used.
2. Fujifilm instax trademark, creative, product and co-marketing authorization.
3. Existing category, territorial and product exclusivity clearance, especially beauty/fashion overlaps.
4. Compatibility testing: generated PNG can be saved; the user must follow the authorized printer app flow. Do not represent a web-to-printer integration as implemented.
5. If photo uploads, minors, contests, analytics or UGC moderation are introduced, complete privacy, safeguarding, content licensing and accessibility reviews. Current prototype stores no personal information on a server.
6. Check local consumer law, promotion rules, advertising disclosure, taxes, refunds, inventory and customs.

## Decision gates and measurement
- **Gate 0:** obtain expressions of interest, rights feasibility and category clearance; otherwise stop.
- **Gate 1:** usability testing of actual prototype, photo printer output, accessible languages and offline fallback; fix critical defects.
- **Gate 2:** one-market pilot, pre-registered KPIs: card completion, save/export rate, optional print intent vs actual prints, retailer product trial, verified attributable sales, customer support burden, negative feedback and brand safety. No benchmark values invented.
- **Gate 3:** compare unit contribution after product costs, fees, rights, tax, retail and support; decide expand, redesign or stop.

## Revenue model caveat
The website calculator is a **what-if sensitivity calculator**, not a sales projection. Its default units, price, cost, fee, royalty and fixed cost are placeholders and must be replaced by real quotes. It omits many relevant items (tax, returns, territory FX, printer depreciation, logistics, marketing attribution). Do not cite its output as predicted campaign profit.

## Strategic limitation / competitive differentiation
This project does not demonstrate a proprietary AI model, unique audience data, exclusive brand relationship, superior negotiation, or a defensible SaaS moat. The potential service differentiation to test later is *a faster, rights-aware, cross-market pipeline from evidence to executable brand activation*, not generic AI idea generation. The academic artifact proves workflow feasibility only; actual buyer willingness to pay requires interviews and controlled pilots.
