# Research & Evidence Register — November 1, 2026

## Public facts

1. KATSEYE's official biography describes HYBE × Geffen's global girl group with six members of different cultural backgrounds. https://www.katseye.world/story-of-katseye/
2. KATSEYE's official film page describes the group's connection to EYEKONS and its global fandom. https://www.katseye.world/film/
3. LANEIGE announced KATSEYE as a global partner for JuicePop Box Lip Tint on January 26, 2026. https://www.prnewswire.com/news-releases/laneige-unveils-katseye-as-global-partner-and-faces-of-new-juicepop-box-lip-tint-campaign-302670191.html
4. Matrix announced KATSEYE as global brand ambassadors for Matrix Moves on February 19, 2026. https://www.prnewswire.com/news-releases/matrix-announces-global-girl-group-katseye-as-new-global-brand-ambassadors-302692207.html

## Reasoned choices, not empirical findings

- Because KATSEYE has existing beauty deals, another standard beauty collaboration offers a less distinctive exercise and raises potential exclusivity questions.
- The proposed instant-photography category provides a way to connect cultural identity, participatory creation, optional product sales, and physical memories. This is creative fit, not verified consumer demand.
- The brand instax is named as a *hypothetical candidate*; no agreement or evidence of willingness to participate.

## Unknowns / required real-world diligence

- Artist/brand existing contracts, exclusivity and image/music rights
- Audience overlap and actual fan interest
- Printing and hardware/product integration feasibility
- Actual consumer pricing, variable costs, fixed costs, royalty structures, taxes, retail fees and conversion rates
- Consumer privacy, UGC moderation, age-appropriate access and location-specific compliance

No Spotify monthly listener or social follower counts are asserted; those change and have not been verified for this project.
