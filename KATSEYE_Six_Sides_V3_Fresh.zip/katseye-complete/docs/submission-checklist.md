# MB-457 Assignment 2 submission checklist

- [x] Pre-proposal — `docs/pre-proposal.md`
- [x] Finished creative artifact — `index.html` (open in browser), plus business model, fan card creator, market strategy and deal room
- [x] Original inputs / prompts — `docs/ai-process.md` and conversation; specific instructions reproduced
- [x] Two intermediate versions — `versions/v0-original.html`, `versions/v1-strategy.md`; V2/V3 iteration details in process document
- [x] Description of AI strengths / weaknesses — `docs/ai-process.md`
- [x] Material user decisions expressed in conversation — `docs/ai-process.md`
- [x] Provenance / tools / source assets — `docs/ai-process.md`, `docs/research.md`, `docs/market-partnership-analysis.md`
- [ ] **Student must actually test and review the final artifact**, record a real personal critique and final edit. Do not claim this is done.
- [ ] Confirm submission format, Canvas timezone, and whether professor requires PDF, link, video or ZIP. This is not verified.

Suggested delivery: upload the ZIP and a short submission note explaining how to open `index.html`. If instructor requires a single document, export the pitch to PDF using browser Print and include it as supporting artifact.
