# MB-457 — Human + Machine Creative Lab
## Pre-Proposal: SIX SIDES / ONE WORLD

**Artifact:** An interactive, mobile-first speculative KATSEYE × FUJIFILM instax partnership campaign, supported by a research ledger, commercial model, and brand pitch.

**Business problem:** Artist/brand teams need to move from broad cultural relevance to a commercially plausible activation. AI can accelerate synthesis, concept development, scenario framing, copy and prototype production, but it cannot establish demand or contractual feasibility.

**Why KATSEYE:** A cross-cultural pop group with an established commercial track record, offering a case for *expanding* partnerships, not assuming they lack representation.

**Proposed collaboration:** SIX SIDES / ONE WORLD invites fans to create digital city-memory cards for free, with a hypothetical optional instax-compatible physical print or product experience. The campaign emphasizes participation, personal identity and transparent optional purchasing rather than randomized collectibles.

**Deliverables:** Functional card creator and downloadable PNG; complete campaign narrative; editable unit-economics scenario; evidence and assumption ledger; prompts and intermediate versions; AI/human reflection; source provenance.

**AI role:** Research synthesis, opportunity comparison, campaign ideation, code generation, copy drafting, business-structure mapping and design iteration. No live AI API is embedded in the site.

**Human role:** Select the strategic question, challenge the generic initial prototype, choose artist and partner direction, reject unsourced market figures, set consumer-experience principles, and review the final campaign. The student's own final decisions and reflection should be appended before submission.

**Success criterion:** A coherent, usable concept whose business assumptions and unknowns are explicit—not proof of actual commercial demand or brand interest.

**Disclosure:** Entire project is speculative and unaffiliated with the named artist or brand.
