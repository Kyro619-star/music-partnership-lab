# AI Process, Prompts, and Reflection — MB-457

## Provenance
Tool/model: OpenAI ChatGPT, GPT-6. Role: research synthesis, concept ideation, commercial model framing, copy, HTML/CSS/JavaScript generation. Runtime uses browser JavaScript only. No live model, external SDK, paid API, customer database, or analytics service is integrated. No artist photos, music, or official logos were copied.

## Original build prompt (actual direction)
"Build a complete, functional, mobile-first KATSEYE brand partnership campaign prototype for MB-457, not just an HTML pitch deck. Use verified public information, choose one defensible speculative brand partner, build a fan-facing interactive experience, define actual commercial mechanisms, add a transparent editable financial scenario, preserve intermediate iterations, disclose AI limitations and human decisions, and clearly mark all unapproved partnerships as unofficial. Avoid invented metrics, fake testimonials, fabricated research, copyrighted music and official artist images."

## Version record
- V0: `versions/v0-original.html` — category exploration, generic digital-identity pitch and evidence placeholders.
- V1: `versions/v1-strategy.md` — source-informed selection of instant-photography direction, defined consumer experience and business model.
- V2: `index.html` — functioning fan card creator with PNG export; commercial scenario calculator; eight-slide pitch; evidence register; research and process documentation.

## AI did well
- Organized a cross-disciplinary workflow quickly: public evidence → category selection → activation → commercial architecture → executable web experience.
- Produced usable code and structured presentation materials, allowing real interaction rather than only describing an idea.
- Surfaced practical diligence gates such as rights clearance, manufacturing costs and fan privacy.

## AI did poorly / limitations
- Initial suggestions were broad and undifferentiated.
- Public data cannot prove brand interest, audience overlap, contract terms or purchase conversion.
- Financial inputs are illustrative assumptions, not industry research or a forecast.
- AI-generated commercial ideas require human cultural judgment, rights review and partner feedback.

## Material human decisions already expressed in the conversation
- The project should focus on music commercialization, revenue innovation and artist–brand partnerships.
- The tool/service should support existing partnership teams, not assume all artists lack representation.
- KATSEYE was selected as the artist case study.
- The artifact should be functional and coded, not merely a text report or slide deck.
- AI outputs must not be represented as verified private market data.

## Student editorial reflection — TO COMPLETE HONESTLY
Before submission, personally try the site and write 100–200 words: What would you keep? What feels generic or commercially unrealistic? Which change did you request or make, and why? What did the tool accomplish that a generic chat response did not? Do not claim fan interviews, industry interviews, actual sales or human edits that did not occur.

## V3 — market-by-market and partner handoff implementation (Nov 1, 2026)
The user explicitly asked to build the complete campaign logic, verified artist data, region-specific execution and a *working* prototype, not simply slides or a static HTML document. In response, the project was expanded with:
- a three-market interactive strategy module (US, Philippines, Brazil), with localization, market-specific activation and go/no-go tests;
- a partner decision room with editable roles, territories, objectives and constraints and downloadable negotiation brief;
- dated Chartmetric and StreamClout third-party audience observations, clearly differentiated from consumer demand;
- a complete commercial strategy and activation playbook with rights, operational ownership and validation gates.
The implementation is deterministic client-side JavaScript. **No real-time AI inference or industry partner data connection exists**. The commercial selection and language drafts are AI-assisted hypotheses and have not been validated by the student or brands.

### Additional user-supplied instructions (verbatim)
"直接帮我做出整个逻辑和campaign，不是只是html或者ppt那种… 。符合老师要求。把项目推进成了一个有完整商业逻辑、真实研究依据和可操作可视化展示的 Campaign Prototype，不再只是 HTML 展示页或 PPT。我睡觉了，生成真的prototype，以及合作分析，展示，搜集katseye的数据，资料，构成真实合作可能性，branding campaign的感觉。覆盖不同地区，下一步plan"

### Version integrity
V0 and V1 are retained as earlier artifacts. V2 is the initial working site. V3 is the current upgraded working site. To avoid retroactively pretending a version existed, V2 source was preserved in `versions/v2-before-market-expansion.html` before adding V3 (if present). The student's actual personal feedback and edits remain to be documented; no fictional student reflection is supplied.
