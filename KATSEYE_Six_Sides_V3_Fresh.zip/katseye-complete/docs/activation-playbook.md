# Campaign activation playbook — partner-facing handoff

## Creative platform
**SIX SIDES / ONE WORLD**: a collective of individual city memories. Visual codes: six-sided geometry, instant-photo frame, soft neon and analog typography; not copied from official KATSEYE art. Master copy: *Keep the moment. Share the world.* Every market has its own optional localized creative; no fake official branding.

## User journey (current prototype)
1. Visit mobile site → see unofficial disclosure and campaign premise.
2. Open **Fan experience** → select city, language, palette; write a personal line.
3. Live preview updates → export PNG to device. This is real local browser functionality.
4. Optional hypothetical authorized retail activation: consumer visits partner event, uses Fujifilm-approved app/printer workflow. **Not implemented** in this prototype.
5. No account, server submission, payment, user analytics, official brand purchase or print integration exists.

## Asset production matrix
| Asset | Existing in prototype? | Real campaign owner | Approval needed |
|---|---|---|---|
| Interactive personalized memory card | Yes, HTML/JS + PNG export | Creative/development | QA + rights review |
| English/Spanish/Korean card headings | Yes, prototype-level | Localization | Native language review |
| US/Philippines/Brazil market cards | Yes, interactive | Regional brand marketing | Regional strategy & copy approval |
| Campaign pitch | Yes, site and exportable partner brief | Partnership strategy | Artist and brand teams |
| Instax hardware integration | No | Fujifilm product team | API/app compatibility and brand approval |
| Retail pop-up, staffing, film supply | No | Retail activation agency | Contract, insurance, budgets |
| Music/video/artist photography | No | Rights owners / production | Licenses, talent sign-off |

## Proposed creative sequence
- **Tease:** short abstract city-photo stories, no unauthorized KATSEYE assets.
- **Reveal:** approved artist × instax creative and the value proposition (only if deal signed).
- **Participate:** mobile story-card generation, creator demonstrations, accessibility-first copy.
- **Optional print:** product demonstration with a clear purchase/print path, no pressure to buy.
- **Sustain:** opt-in community gallery only if consent, moderation and age-safety resources exist. Current prototype deliberately has no public gallery.

## Sample channel messages — DRAFTS, NOT REAL ADS
- US: "Your city. Your side. Make a memory you can keep."
- Philippines: "Your story, your city. Make a moment worth keeping." (Filipino localization requires native review.)
- Brazil: "Sua cidade. Sua história. Um momento para guardar." (Portuguese localization requires native review.)

## 6-week *hypothetical* pilot schedule (starts only after agreements)
- Week 0: rights, partner buy-in, category conflict and budgets.
- Week 1: prototype QA, printer compatibility, localization and privacy.
- Week 2: retail location and distribution confirmation, staff training, baseline definition.
- Week 3: controlled launch in one city with consent-based measurement.
- Week 4: review product trial, print completion, qualitative friction, support and cost.
- Week 5: adjust creative and activation; repeat only if justified.
- Week 6: decision meeting: expand, pivot or stop.

## What would falsify the concept?
- Partner exclusivity prohibits photography collaboration.
- Most users save a card but show little interest in actual printing; no measurable hardware/film effect.
- Print workflow is too complicated or expensive in priority markets.
- Commercial fees/rights exceed plausible incremental value.
- Localized creative feels generic or culturally inauthentic.

## Responsible use of AI
AI assists evidence synthesis, campaign options, localized first drafts, interface code and structured pitch generation. Human approval is mandatory for commercial claims, legal/rights terms, cultural interpretation and go/no-go decisions. This prototype does not run a live AI model; AI was used during creation.
